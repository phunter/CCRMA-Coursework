//
//  StructureArt.h
//  Assignment1
//
//  Created by phunter on 10/5/11.
//  Copyright 2011 Hunter McCurry. All rights reserved.
//

#include "GraphCreature.h"

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif


using namespace std;

// Class for this specific art drawing
class StructureArt {
private:
    float minX, maxX, minY, maxY;
    vector<GraphCreature> creature_list;
    Point last_mouse;
    int creature_counter;

    
public:
    
    // Constructor uses default arguments to allow calling with zero, one, or two values.
    StructureArt(float X1, float X2, float Y1, float Y2);
    
    void populate(int n, int s);
    void resizeWindow(float X1, float X2, float Y1, float Y2);
    void draw();
    void update();
    void addNode(float x, float y);
    void finishCreature();
    
    // Print Point Info
    void print_me();
};