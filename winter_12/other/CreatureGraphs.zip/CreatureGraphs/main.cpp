//
//  main.cpp
//  Rainbow Worms
//
//  Originally created for Stanford CS 148 fall 11.
//  Copyright 2011 Hunter McCurry. All rights reserved.
//

#include <stdlib.h>
#include <vector>
#include <stdio.h>
#include <iostream>
#include <time.h>
#include "StructureArt.h"


#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif


bool spew = false;
int mouseX;
int mouseY;

bool FullScreen = 0;
int win_width = 1440;
int win_height = 900;

int cur_width = win_width;
int cur_height = win_height;

int initial_creatures = 2;
int initial_size = 7;

StructureArt art(-1, 1, (-(float)win_height/win_width), ((float)win_height/win_width));

void tick(int value)
{
    if (spew) {
        art.addNode(mouseX/(float)cur_width, 1-mouseY/(float)cur_height);
    }
    
    // reschedule
    glutTimerFunc(16.0f, tick, 0);
    // redisplay
    glutPostRedisplay();
}
 
void display( void )
{
    //glClearColor(1.0, 1.0, 1.0, 1.0);
    glClear(GL_COLOR_BUFFER_BIT); 

    art.draw();
    art.update();
    
    glFlush();

    glutSwapBuffers();
}


void reshape( int w, int h )
{
    glMatrixMode( GL_PROJECTION );
    glLoadIdentity();

    cur_width = w;
    cur_height = h;
    
    art.resizeWindow( -w/win_width, w/win_width, (-(float)win_height/win_width)*(h/win_height), ((float)win_height/win_width)*(h/win_height) );
    
    glOrtho( -w/win_width, w/win_width, (-(float)win_height/win_width)*(h/win_height), ((float)win_height/win_width)*(h/win_height), -1., 1. );
    glViewport( 0, 0, w, h);
        
    glutPostRedisplay();
}

void mouse(int button, int state, int x, int y)
{
    if (state == 0) {
        spew = true;
        
        mouseX = x;
        mouseY = y;
    }
    else {
        spew = false;
        art.finishCreature();
    }
}

void mouseMove( int x, int y ) {
    mouseX = x;
    mouseY = y;
}

void keyboard( unsigned char key, int x, int y ) {
    switch(key) {
        case 27: // Escape to exit program
            exit(0);
            break;
    }
}


int main (int argc, char *argv[]) {
    
    glutInit( &argc, argv );
    glutInitDisplayMode( GLUT_RGBA | GLUT_DOUBLE );
   
    
    if (FullScreen) {
        // These 2 lines for full screen mode
        glutGameModeString("1440x900:32@75"); // assumed MacBook Pro dimensions
        glutEnterGameMode();

    }
    else {
        // These 3 lines for for windowed mode
        cur_width = win_width = 1300;
        cur_height = win_height = 800;

        glutInitWindowSize( win_width, win_height );
        glutInitWindowPosition(50,50);
        glutCreateWindow( "Rainbow Worms!" );    
    }
        
    glutDisplayFunc( display );
    glutReshapeFunc( reshape );
    glutMouseFunc( mouse );
    glutMotionFunc( mouseMove );
    glutKeyboardFunc( keyboard );
 
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    
    
    /* initialize random seed: */
    srand ( time(NULL) );
    
    art.populate(initial_creatures, initial_size);
    
    // 16 msecs
    glutTimerFunc(16.0f, tick, 0);

    glutMainLoop();
}
