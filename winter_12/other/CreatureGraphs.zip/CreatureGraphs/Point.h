//
//  Point.h
//  Assignment1
//
//  Created by phunter on 10/4/11.
//  Copyright 2011 Hunter McCurry. All rights reserved.
//

#include <iostream>
#include <math.h>
#include <vector>

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

using namespace std;

// Class to represent points.
class Point {
private:
    double xval, yval;
    GLfloat point_size;
    vector<float> point_color;
    
public:
    // Constructor uses default arguments to allow calling with zero, one, or two values.
    Point(double x = 0.0, double y = 0.0)
    {
        xval = x;
        yval = y;
        point_size = 5;
        point_color.assign(4, 1.0);
    }
    
    // Extractors.
    double x() { return xval; }
    double y() { return yval; }
    int size() { return point_size; }
    vector<float> color() { return point_color; }
    
    // Distance to another point.  Pythagorean thm.
    double dist(Point other) {
        double xd = xval - other.xval;
        double yd = yval - other.yval;
        return sqrt(xd*xd + yd*yd);
    }
    
    // Move the existing point.
    void relocate(double a, double b)
    {
        xval = a;
        yval = b;
    }
    
    // Change size
    void resize(int a)
    {
        point_size = a;
    }
    
    // Change color
    void recolor(float r, float g, float b, float a)
    {
        point_color[0] = r;
        point_color[1] = g;
        point_color[2] = b;
        point_color[3] = a;
    }
    
    virtual void draw()
    {
        glPointSize(point_size);
        glColor4f(point_color[0], point_color[1], point_color[2], point_color[3]);
        glVertex2f(xval, yval);
    }
    
    // Print Point Info
    void print_me();
};
