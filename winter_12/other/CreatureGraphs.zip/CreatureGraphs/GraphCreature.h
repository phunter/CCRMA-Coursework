//
//  GraphCreature.h
//  Assignment1
//
//  Created by phunter on 10/6/11.
//  Copyright 2011 Hunter McCurry. All rights reserved.
//

#include "Triangle.h"

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif


using namespace std;

// Class for this specific art drawing
class GraphCreature {
private:
    int graph_size;
    vector<Point> node_list;
    double ideal_dist;
    double speed;
    double draw_type;
    double h_drift; // horizontal drift
    double v_drift; // vertical drift
    
    vector<Triangle> triangle_list;
    vector<double> ideal_list;
    
public:
    
    // Constructor uses default arguments to allow calling with zero, one, or two values.
    GraphCreature();
    
    void populate(int s);
    void draw();
    void update();
    void addNode(float x, float y);
    void makeTriangles(Point p);
    
    // Helper Random Function
    double getRando();
    
    // Print Point Info
    void print_me();
};