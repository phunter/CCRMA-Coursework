//
//  Triangle.h
//  Assignment1
//
//  Created by phunter on 10/5/11.
//  Copyright 2011 Hunter McCurry. All rights reserved.
//

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include <Point.h>

class Triangle {
    vector<int> nodes;
    
public:
    Triangle(int p1, int p2, int p3) {
        nodes.push_back(p1);
        nodes.push_back(p2);
        nodes.push_back(p3);
    }
    
    int getNode(int num) { return nodes[num]; }
    
    void draw();
};