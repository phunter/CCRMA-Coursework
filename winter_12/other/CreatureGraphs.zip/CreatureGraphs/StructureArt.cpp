//
//  StructureArt.cpp
//  Assignment1
//
//  Created by phunter on 10/5/11.
//  Copyright 2011 Hunter McCurry. All rights reserved.
//

#include "StructureArt.h"

StructureArt::StructureArt(float X1, float X2, float Y1, float Y2)
{
    minX = X1;
    maxX = X2;
    minY = Y1;
    maxY = Y2;

    last_mouse.relocate(0.0, 0.0);
    creature_counter = 0;
}


void StructureArt::populate(int n, int s)
{
    GraphCreature g, b;
    creature_list.push_back(g);
    creature_list.push_back(b); 
    creature_counter = n;
    for (int i = 0; i < creature_counter; i++) {
        creature_list[i].populate(s);
        finishCreature();
        //addNode(getRando(), getRando());
    }
}

// Window Resizing is not currently working
void StructureArt::resizeWindow(float X1, float X2, float Y1, float Y2)
{
    minX = X1;
    maxX = X2;
    minY = Y1;
    maxY = Y2;
}

void StructureArt::draw()
{
    for (int i = 0; i < creature_list.size(); i++) {
        creature_list[i].draw();
    }
    //printf("StructureArt Draw\n");
}

void StructureArt::update()
{
    for (int i = 0; i<creature_list.size(); i++) {
       creature_list[i].update();
    }
    // printf("StructureArt Update\n");
}

void StructureArt::addNode(float x, float y)
{
    
    float scaled_x = minX + (maxX - minX) * x;
    float scaled_y = minY + (maxY - minY) * y;
    
    creature_list[creature_list.size()-1].addNode(scaled_x, scaled_y);
}

void StructureArt::finishCreature()
{
    GraphCreature g;
    creature_list.push_back(g);
}

void StructureArt::print_me()
{
    printf("Print out da info about the art here");
    
    //printf("Location: ( %f, %f )\nColor: ( %f, %f, %f, %f )\nSize: %f\n", \
    xval, yval, node_color[0], node_color[1], node_color[2], node_color[3], node_size);    
}