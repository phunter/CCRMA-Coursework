//
//  GraphCreature.cpp
//  Assignment1
//
//  Created by phunter on 10/6/11.
//  Copyright 2011 Hunter McCurry. All rights reserved.
//

#include "GraphCreature.h"

GraphCreature::GraphCreature()
{
    graph_size = 0;
    ideal_dist = 0.25 * getRando() + .05;
    speed = 0.5;
    draw_type = getRando();
    h_drift = .06 * getRando();
    v_drift = .06 * getRando();
    
    ideal_list.push_back(.1);
}


void GraphCreature::populate(int s)
{
    for (int i = 0; i < s; i++) {
        addNode(2*getRando()-1, 2*getRando()-1);
    }
}


void GraphCreature::draw()
{
    glLineWidth(5);
    
    // select draw mode
    if (draw_type < .33) {
        glBegin(GL_POLYGON);
    }
    else if ( draw_type < .66 ) {
        glBegin(GL_LINE_STRIP);
    }
    else {
        glBegin( GL_TRIANGLES );
    }
        
    
    
    for (int i = 0; i < triangle_list.size(); i++) {
        for (int j = 0; j < 3; j++) {
            node_list[triangle_list[i].getNode(j)].draw();
        }
    }
    glEnd();
}

void GraphCreature::update()
{
    
    for (int k = 0; k < triangle_list.size(); k++) {
        for (int i = 0; i < 2; i++) {
            for (int j = i+1; j < 3; j++) {
                
                // THIS WHOLE SECTION IS NEEDLESSLY CONFUSING
                // TODO: use geometric point and vector class to clean up math
                
                double this_ideal = ideal_dist * (fabs(sin(k/13.0 + sin(k/17.0) + .7))+.01);
                //double this_ideal = ideal_list[k];
                
                int here = triangle_list[k].getNode(i);
                int there = triangle_list[k].getNode(j);
                
                double cur_dist = node_list[here].dist(node_list[there]);
                
                double here_new_x = node_list[here].x() + ((node_list[there].x() - node_list[here].x()) * (cur_dist - this_ideal))*speed;
                double here_new_y = node_list[here].y() + ((node_list[there].y() - node_list[here].y()) * (cur_dist - this_ideal))*speed;
                
                double there_new_x = node_list[there].x() + ((node_list[here].x() - node_list[there].x()) * (cur_dist - this_ideal+v_drift))*speed;
                double there_new_y = node_list[there].y() + ((node_list[here].y() - node_list[there].y()) * (cur_dist - this_ideal+h_drift))*speed;
                
                node_list[here].relocate(here_new_x, here_new_y);
                node_list[there].relocate(there_new_x, there_new_y);
            }
        }
    }
}

void GraphCreature::addNode(float x, float y)
{
    Point p;
    p.relocate(x, y);
    p.resize( 30 );
    p.recolor(getRando(), getRando(), getRando(), getRando()*.5 + .1);
    
    // first make a triangle with it
    if (graph_size >= 2) {
        makeTriangles(p);
    }
    
    // then add it to the list of nodes
    node_list.push_back(p);
    graph_size++;
}

void GraphCreature::makeTriangles(Point p)
{
    // 1) find closets 2 points
    // indices of the closest two points
    int c1 = 0;
    int c2 = 1;
    
    // distances to the closest two points
    double d1 = p.dist(node_list[c1]);
    double d2 = p.dist(node_list[c2]);
    
    if (d2 < d1) {
        double tmp = d1;
        d1 = d2;
        d2 = tmp;
        int tmp2 = c1;
        c1 = c2;
        c2 = tmp2;
    }
    
    for (int i = 2; i < graph_size; i++) {
        
        float cur_dist = p.dist(node_list[i]);
        if (cur_dist < d2) {
            d2 = cur_dist;
            c2 = i;
        }
        
        // bookkeeping: shuffle c1 and c2 if they are out of order
        if (d2 < d1) {
            double tmp = d1;
            d1 = d2;
            d2 = tmp;
            int tmp2 = c1;
            c1 = c2;
            c2 = tmp2;
        }
    }
    
    Triangle t( graph_size, c1, c2 );
    triangle_list.push_back(t);
}

// returns random double between 0 and 1
double GraphCreature::getRando()
{
    int thing = rand() % 2000;
    double ret_val = thing / 2000.0;
    return ret_val;
}

void GraphCreature::print_me()
{
    printf("Print out da info here");
    
    //printf("Location: ( %f, %f )\nColor: ( %f, %f, %f, %f )\nSize: %f\n", \
    xval, yval, node_color[0], node_color[1], node_color[2], node_color[3], node_size);    
}