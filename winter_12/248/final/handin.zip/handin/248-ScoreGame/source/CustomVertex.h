//
//  CustomVertex.h
//  248-ScoreGame
//
//  Created by Hunter McCurry on 3/16/12.
//  Copyright (c) 2012 Oberlin College. All rights reserved.
//

#ifndef _48_ScoreGame_CustomVertex_h
#define _48_ScoreGame_CustomVertex_h

struct CustomVertex
{
	aiVector3D position;
	aiVector3D normal;
};


#endif
