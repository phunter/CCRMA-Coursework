//
//  NoteMessge.h
//  GraphScore
//
//  Created by phunter on 2/1/12.
//  Copyright 2012 Hunter McCurry. All rights reserved.
//

#ifndef GraphScore_NoteMessage_h
#define GraphScore_NoteMessage_h

struct NoteMessage {
public:    
    int note_num;
    int note_vel;
};


#endif
