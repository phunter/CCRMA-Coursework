SUNet ID: hmccurry
Development platform: Mac OSX 10.7 64-bit, Xcode 4.2.1

User controls:
Mouse - Look left, right, up, down
Keyboard:
	W - move forward (includes the ability to fly)
	S - move backward
	A - move left
	D - move right
	SPACE - move upward (always towards positive Y)
	C - move downward (always towards negative Y)

I included several classes from LibST taken from CS148, because at the time I didn't realize that SFML had similar classes already implemented.

Alas! Shadow mapping never made it into the submission. This is a terrible shame :(