// STPoint2.cpp
#include "STPoint2.h"

#include "STVector2.h"

//

const STPoint2 STPoint2::Origin(0.0f, 0.0f);
