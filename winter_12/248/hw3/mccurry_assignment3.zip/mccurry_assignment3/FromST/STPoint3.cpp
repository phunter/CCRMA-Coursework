// STPoint3.cpp
#include "STPoint3.h"

#include "STVector3.h"

//

const STPoint3 STPoint3::Origin(0.0f, 0.0f, 0.0f);
